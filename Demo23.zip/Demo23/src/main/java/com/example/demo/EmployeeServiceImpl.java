package com.example.demo;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class EmployeeServiceImpl implements EmployeeService{

	
	
	 @Autowired
	 EmployeeRepository employeeRepository;
	 
	 
	@Override
	public Employee save(Employee e) {
		// TODO Auto-generated method stub
		return  employeeRepository.save(e);
	}


	@Override
	public Optional<Employee> findById(Integer var) {
		// TODO Auto-generated method stub
		return employeeRepository.findById(var);
	}


	@Override
	public List<Employee> findAll() {
		// TODO Auto-generated method stub
		return employeeRepository.findAll();
	}


//	@Override
//	public List<Employee> findbyAddress(String address) {
//		// TODO Auto-generated method stub
//		return employeeRepository.findByAddress(address);
//	}


	@Override
	public List<Employee> findbyName(String name) {
		// TODO Auto-generated method stub
		return employeeRepository.findByName(name);
	}


	@Override
	public List<Employee> sortbyName() {
		// TODO Auto-generated method stub
		return employeeRepository.findAllSortedByName();
	}

}
