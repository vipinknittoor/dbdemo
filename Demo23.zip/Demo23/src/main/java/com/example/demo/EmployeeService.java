package com.example.demo;

import java.util.List;
import java.util.Optional;

public interface EmployeeService {
	
	Employee save(Employee e);

	Optional<Employee> findById(Integer var);
	List<Employee> findAll();

	List<Employee> findbyAddress(String address);

	List<Employee> findbyName(String name);

	List<Employee> sortbyName();

}
