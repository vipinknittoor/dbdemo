package com.example.demo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

	//List<Employee> findByAddress(String address);

	List<Employee> findByName(String name);

	@Query(value = "SELECT e FROM Employee e ORDER BY name")
	public List<Employee> findAllSortedByName();
//	@Query(value = "SELECT e FROM Employee e ORDER BY address")
//	public List<Employee> findByAddress();
}
